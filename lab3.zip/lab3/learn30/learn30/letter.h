#pragma once

#ifndef LETTER_H
#define LETTER_H

void drawCNString(const char* str);

#endif